document.addEventListener("DOMContentLoaded", function() {
    console.log("✅ Script berjalan!");

    const buttons = document.querySelectorAll(".menu-item .pesan-btn");
    console.log(`🔍 Jumlah tombol 'Pesan' ditemukan: ${buttons.length}`);

    const cartItems = document.getElementById("cart-items");
    const cartTotal = document.getElementById("cart-total");
    const checkoutBtn = document.getElementById("checkout-btn");

    if (!cartItems || !cartTotal || !checkoutBtn) {
        console.error("⚠️ Elemen keranjang tidak ditemukan!");
        return;
    }

    let cart = [];
    
    buttons.forEach(button => {
        button.addEventListener("click", function() {
            console.log("🛒 Tombol pesan diklik!");
            const itemName = this.parentElement.querySelector("h3").textContent;
            const itemPrice = parseInt(this.parentElement.querySelector("p").textContent.replace("Rp ", "").replace(".", ""));
            
            cart.push({ name: itemName, price: itemPrice });
            console.log("📦 Item ditambahkan ke keranjang:", cart);
            updateCart();
        });
    });

    function updateCart() {
        console.log("♻️ Memperbarui keranjang...");
        cartItems.innerHTML = "";
        let total = 0;
        
        cart.forEach((item, index) => {
            total += item.price;
            const li = document.createElement("li");
            li.textContent = `${item.name} - Rp ${item.price}`;

            const removeBtn = document.createElement("button");
            removeBtn.textContent = "Hapus";
            removeBtn.addEventListener("click", function() {
                cart.splice(index, 1);
                updateCart();
            });

            li.appendChild(removeBtn);
            cartItems.appendChild(li);
        });

        cartTotal.textContent = `Rp ${total}`;
    }

    checkoutBtn.addEventListener("click", function() {
        if (cart.length === 0) {
            alert("Keranjang masih kosong!");
        } else {
            alert("Pesanan anda telah diproses!");
            cart = [];
            updateCart();
        }
    });
});
